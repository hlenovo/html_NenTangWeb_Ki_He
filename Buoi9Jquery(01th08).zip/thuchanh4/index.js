let users = [];
let editIndex = -1;

function renderTable() {
  const tbody = $("table tbody");
  tbody.empty();
  users.forEach((user, index) => {
    tbody.append(`
      <tr>
        <td>
          <button class="edit-btn" data-index="${index}">✏️</button>
          <button class="delete-btn" data-index="${index}">❌</button>
        </td>
        <td>${index + 1}</td>
        <td>${user.ten}</td>
        <td>${user.hodem}</td>
        <td>${user.diachi}</td>
        <td>✔️</td>
      </tr>
    `);
  });
}

function resetForm() {
  $("#userForm")[0].reset();
  editIndex = -1;
  $("#formPopup h2").text("Thêm người dùng");
}

$(document).ready(function () {
  console.log("Trang đã tải xong");

  // Lấy dữ liệu từ file data.json khi khởi động
  $.getJSON("data.json", function (data) {
    console.log("Đã load dữ liệu từ JSON:", data);
    users = data;
    renderTable();
  });

  // Mở popup
  $("#openForm").click(function () {
    resetForm();
    $("#formPopup").show();
  });

  // Đóng popup
  $("#closeForm").click(function () {
    $("#formPopup").hide();
  });

  $(window).click(function (e) {
    if (e.target.id === "formPopup") {
      $("#formPopup").hide();
    }
  });

  // Validate form
  $("#userForm").validate({
    rules: {
      ten: "required",
      hodem: "required",
      diachi: "required",
    },
    messages: {
      ten: "Vui lòng nhập tên",
      hodem: "Vui lòng nhập họ đệm",
      diachi: "Vui lòng nhập địa chỉ",
    },
  });

  // Xử lý nút Lưu
  $("#saveBtn").click(function () {
    if ($("#userForm").valid()) {
      const newUser = {
        ten: $("#ten").val(),
        hodem: $("#hodem").val(),
        diachi: $("#diachi").val(),
      };

      if (editIndex === -1) {
        users.push(newUser);
      } else {
        users[editIndex] = newUser;
      }

      renderTable();
      $("#formPopup").hide();
      resetForm();
    }
  });

  // Sửa người dùng
  $(document).on("click", ".edit-btn", function () {
    editIndex = $(this).data("index");
    const user = users[editIndex];
    $("#ten").val(user.ten);
    $("#hodem").val(user.hodem);
    $("#diachi").val(user.diachi);
    $("#formPopup h2").text("Chỉnh sửa người dùng");
    $("#formPopup").show();
  });

  // Xóa người dùng
  $(document).on("click", ".delete-btn", function () {
    const index = $(this).data("index");
    if (confirm("Bạn có chắc muốn xóa người dùng này không?")) {
      users.splice(index, 1);
      renderTable();
    }
  });
});
