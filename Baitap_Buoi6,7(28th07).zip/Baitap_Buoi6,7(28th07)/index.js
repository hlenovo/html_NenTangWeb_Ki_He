function validateForm() {
  const maSV = document.getElementById("maSV").value.trim();
  const hoTen = document.getElementById("hoTen").value.trim();
  const email = document.getElementById("email").value.trim();
  const ngaySinh = document.getElementById("ngaySinh").value;
  const gioiTinhNam = document.getElementById("nam").checked;
  const gioiTinhNu = document.getElementById("nu").checked;

  if (!maSV || !hoTen || !email || !ngaySinh) {
    alert("Vui lòng nhập đầy đủ thông tin!");
    return false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Email không hợp lệ!");
    return false;
  }

  if (!gioiTinhNam && !gioiTinhNu) {
    alert("Vui lòng chọn giới tính!");
    return false;
  }

  return true;
}

// Hàm gán sự kiện cho từng dòng
function ganSuKienChoDong(row) {
  const nutSua = row.querySelector(".btn-sua");
  const nutXoa = row.querySelector(".btn-xoa");

  nutSua.addEventListener("click", function () {
    const cells = row.getElementsByTagName("td");

    document.getElementById("maSV").value = cells[1].innerText;
    document.getElementById("hoTen").value = cells[2].innerText;
    document.getElementById("email").value = cells[3].innerText;
    document.getElementById("ngaySinh").value = cells[5].innerText;

    const gioiTinh = cells[4].innerText.trim();
    if (gioiTinh === "Nam") document.getElementById("nam").checked = true;
    else if (gioiTinh === "Nữ") document.getElementById("nu").checked = true;

    row.remove();
  });

  nutXoa.addEventListener("click", function () {
    if (confirm("Bạn có chắc muốn xóa dòng này không?")) {
      row.remove();
    }
  });
}

document.addEventListener("DOMContentLoaded", function () {
  let stt = 3;

  // Gán sự kiện cho các dòng có sẵn
  const rows = document.querySelectorAll("#sinhVienTableBody tr");
  rows.forEach((row) => ganSuKienChoDong(row));

  const btnThem = document.getElementById("btnThem");

  btnThem.addEventListener("click", function (event) {
    event.preventDefault();

    if (!validateForm()) return;

    const maSV = document.getElementById("maSV").value;
    const hoTen = document.getElementById("hoTen").value;
    const Email = document.getElementById("email").value;
    const ngaySinh = document.getElementById("ngaySinh").value;
    let gioiTinh = document.getElementById("nam").checked ? "Nam" : "Nữ";

    stt++;
    const newRow = document.createElement("tr");
    newRow.innerHTML = `
      <td>${stt}</td>
      <td>${maSV}</td>
      <td>${hoTen}</td>
      <td>${Email}</td>
      <td align="center">${gioiTinh}</td>
      <td>${ngaySinh}</td>
      <td>
        <button class="btn-sua">Sửa</button>
        <button class="btn-xoa">Xóa</button>
      </td>
    `;

    document.getElementById("sinhVienTableBody").appendChild(newRow);
    ganSuKienChoDong(newRow);
    document.querySelector("form").reset();

    setTimeout(() => {
      alert("Đã thêm sinh viên: " + hoTen + " (" + maSV + ")");
    }, 0);
  });
});
