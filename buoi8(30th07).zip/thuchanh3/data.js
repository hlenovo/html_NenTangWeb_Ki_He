const dataKhachHang = [
  {
    id: 1199,
    khachHang: "Hoài An",
    nhanVien: "Mai Thục Anh",
    soTien: 530000,
    ngayMua: "06/06/2024 09:00",
  },
  {
    id: 1200,
    khachHang: "Minh Quân",
    nhanVien: "Nguyễn Văn A",
    soTien: 1200000,
    ngayMua: "12/06/2024 14:30",
  },
  {
    id: 1201,
    khachHang: "Thùy Trang",
    nhanVien: "Phạm Bích Ngọc",
    soTien: 720000,
    ngayMua: "20/06/2024 10:00",
  },
  {
    id: 1202,
    khachHang: "Anh Đức",
    nhanVien: "Trần Văn Cường",
    soTien: 315000,
    ngayMua: "25/06/2024 11:15",
  },
  {
    id: 1203,
    khachHang: "Mai Hương",
    nhanVien: "Lê Thị Hà",
    soTien: 980000,
    ngayMua: "01/07/2024 16:45",
  },
];
