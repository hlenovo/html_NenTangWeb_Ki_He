let currentID = 1200;

document.addEventListener("DOMContentLoaded", function () {
  const tableBody = document.querySelector("#customerTable tbody");
  let currentID = dataKhachHang[dataKhachHang.length - 1].id + 1;

  // Gán dữ liệu ban đầu từ JSON vào bảng
  dataKhachHang.forEach((item) => {
    const row = `
      <tr>
        <td><input type="checkbox" /></td>
        <td>
          <button class="btn btn-warning btn-sm">✏️</button>
          <button class="btn btn-danger btn-sm">❌</button>
        </td>
        <td>${item.id}</td>
        <td>${item.khachHang}</td>
        <td>${item.nhanVien}</td>
        <td>${item.soTien.toLocaleString()}</td>
        <td>${item.ngayMua}</td>
      </tr>
    `;
    tableBody.insertAdjacentHTML("beforeend", row);
  });

  // Gán sự kiện lưu
  document.getElementById("btnLuu").addEventListener("click", function () {
    const tenKhach = document.getElementById("tenKhach").value.trim();
    const tenNhanVien = document.getElementById("tenNhanVien").value.trim();
    const soTien = document.getElementById("soTien").value.trim();

    // Kiểm tra hợp lệ
    let errors = [];
    if (!tenKhach) errors.push("Vui lòng nhập tên khách hàng.");
    else if (tenKhach.length > 30)
      errors.push("Tên khách hàng không được vượt quá 30 ký tự.");

    if (!tenNhanVien) errors.push("Vui lòng nhập tên nhân viên.");
    else if (tenNhanVien.length > 30)
      errors.push("Tên nhân viên không được vượt quá 30 ký tự.");

    if (!soTien) errors.push("Vui lòng nhập số tiền.");

    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const now = new Date();
    const ngayMua = now.toLocaleString("vi-VN");

    const newRow = `
      <tr>
        <td><input type="checkbox" /></td>
        <td>
          <button class="btn btn-warning btn-sm">✏️</button>
          <button class="btn btn-danger btn-sm">❌</button>
        </td>
        <td>${currentID++}</td>
        <td>${tenKhach}</td>
        <td>${tenNhanVien}</td>
        <td>${parseInt(soTien).toLocaleString()}</td>
        <td>${ngayMua}</td>
      </tr>
    `;
    tableBody.insertAdjacentHTML("beforeend", newRow);
    document.getElementById("addForm").reset();
    const modal = bootstrap.Modal.getInstance(
      document.getElementById("themModal")
    );
    modal.hide();
  });
});
